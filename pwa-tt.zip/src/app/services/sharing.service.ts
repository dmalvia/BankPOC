import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Http, Headers } from '@angular/http';

@Injectable()
export class SharingService {
  private subject = new Subject<any>();
  public status: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public optSelected: BehaviorSubject<string> = new BehaviorSubject<string>('retailBank');

  sendFlag(flagVal: boolean) {
    this.subject.next(flagVal);
  }

  displayOpt(value: boolean) {
        this.status.next(value);
  }

  bankingOpt(value:string) {
    this.optSelected.next(value);
  }

  getData(): Observable<any> {
    return this.subject.asObservable();
  }

  constructor(private http: Http) { }

  getToken(postObj) {

    let headers = new Headers({
    'Authorization': 'key=AAAA6QA_nsg:APA91bEJ1Hdlri4OLy4vSW87IbEjFhOoSelANe6U8WeXXFzwDth-cEhEZ6Mb2GNr1TWE_SUWuII7VGd6hYFAHjxglSciylaEH_ayhTqulxoHdb72xrzg_uYRgdwXR6LHxwnHH8Wzv1y1'
    });

    let url ='https://fcm.googleapis.com/fcm/send';

    return this.http.post(url,postObj,{headers:headers})
    .map(res => {
      return res;
    })
    // .catch(error => {
    //   console.log('error', error);
    // })
  }
}
