export const environment = {
  production: true,
  firebase: {
	  apiKey: "AIzaSyDiQYHif2taEzlom_Uwkm31yh7yFY7Q7Ns",
	  authDomain: "pea-tt.firebaseapp.com",
	  databaseURL: "https://pea-tt.firebaseio.com",
	  projectId: "pea-tt",
	  storageBucket: "pea-tt.appspot.com",
	  messagingSenderId: "1000731549384"
  }
};
