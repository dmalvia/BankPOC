import { Component, OnInit } from '@angular/core';
import { SharingService } from '../../services/sharing.service';

@Component({
  selector: 'app-transactions-authorize',
  templateUrl: './transactions-authorize.component.html',
  styleUrls: ['./transactions-authorize.component.css']
})
export class TransactionsAuthorizeComponent implements OnInit {
  selectedBanking:string;
  dummyTxn:any;
  constructor(private ds: SharingService) { }

  ngOnInit() {
  	this.ds.optSelected.subscribe((res:string) => {
      this.selectedBanking = res;
    });

    this.dummyTxn = [
      {
        "from":"Savings Account",
        "to":"FS Tech Solutions",
        "amount":983,
        "mode":"RTGS",
        "date":"2018-10-15T09:17:36.948Z",
        "remark":"testing"
      },
      {
        "from":"Current Account",
        "to":"Distributors Tech Solutions",
        "amount":983,
        "mode":"NEFT",
        "date":"2018-09-15T09:17:36.948Z",
        "remark":"testing"
      }

    ]
  }

}
