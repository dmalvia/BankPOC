export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBH-J_y2c9HfL4E2tFX80pob2FUwHdqMoc",
    authDomain: "pwa-banking-tt.firebaseapp.com",
    databaseURL: "https://pwa-banking-tt.firebaseio.com",
    projectId: "pwa-banking-tt",
    storageBucket: "pwa-banking-tt.appspot.com",
    messagingSenderId: "230097368996"
  }
};
