import { Component, OnInit } from '@angular/core';
import { MessagingService } from "./services/notification-service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  message: any;
  loadedPage = '';
  position: any;
  onNavigation(displayPage: string) {
    this.loadedPage = displayPage;
  }

  constructor(private messagingService: MessagingService) {
  }
  ngOnInit() {
    const userId = 'user001';
    this.messagingService.requestPermission(userId)
    this.messagingService.receiveMessage()
    this.message = this.messagingService.currentMessage
    // this.fetchLocation();
    console.log("My message" + JSON.stringify(this.message));
    // this.fetchLocation();
    console.log("My message" + JSON.stringify(this.message));
  }


  appendLocation(location, verb) {
    verb = verb || 'updated';
    console.log('Location ' + verb + ': <a href="https://maps.google.com/maps?&z=15&q=' + location.coords.latitude + '+' + location.coords.longitude + '&ll=' + location.coords.latitude + '+' + location.coords.longitude + '" target="_blank">' + location.coords.latitude + ', ' + location.coords.longitude + '</a>');
  }

  fetchLocation() {
    console.log('Hi')
    if ('geolocation' in navigator) {
      console.log('Hi2');
      navigator.geolocation.getCurrentPosition(function (position) {
        console.log('Hi3');
        var lat = position.coords.latitude;
        var lng = position.coords.longitude;
        // alert(lat + " lat and long" + lng);
      });
    }
    else {
      alert('Geo location Api not supported.');
    }
  }

}
