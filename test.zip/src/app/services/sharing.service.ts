import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class SharingService {
  private subject = new Subject<any>();
  public status: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public optSelected: BehaviorSubject<string> = new BehaviorSubject<string>('retailBank');

  sendFlag(flagVal: boolean) {
    this.subject.next(flagVal);
  }

  displayOpt(value: boolean) {
        this.status.next(value);
  }

  bankingOpt(value:string) {
    this.optSelected.next(value);
  }

  getData(): Observable<any> {
    return this.subject.asObservable();
  }

  constructor() { }

}
