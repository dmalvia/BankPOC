// export const firebaseConfig = {
//     apiKey: 'AIzaSyAxK1DWvZp0eYWlrXq05X3iC-s0V3d8IwE',
//     authDomain: 'pwa-banking.firebaseapp.com',
//     databaseURL: 'https://pwa-banking.firebaseio.com',
//     projectId: 'pwa-banking',
//     storageBucket: 'pwa-banking.appspot.com',
//     messagingSenderId: "965912159433"
// }