import { Component, OnInit } from '@angular/core';
import { SharingService } from '../../services/sharing.service';

@Component({
  selector: 'app-transactions-authorize',
  templateUrl: './transactions-authorize.component.html',
  styleUrls: ['./transactions-authorize.component.css']
})
export class TransactionsAuthorizeComponent implements OnInit {
  selectedBanking:string;
  constructor(private ds: SharingService) { }

  ngOnInit() {
  	this.ds.optSelected.subscribe((res:string) => {
      this.selectedBanking = res;
    })
  }

}
